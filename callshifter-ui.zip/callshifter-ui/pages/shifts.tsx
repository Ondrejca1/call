export default function Shifts() {
  return (
    <main style={{ padding: 40 }}>
      <h1>Směny</h1>
      <ul>
        <li>Pondělí–Pátek: 8:00–16:00</li>
        <li>Víkendy: zavřeno</li>
      </ul>
    </main>
  );
}