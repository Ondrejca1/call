export default function Hours() {
  return (
    <main style={{ padding: 40 }}>
      <h1>Provozní doba</h1>
      <p>Po–Pá: 8:00–16:00</p>
      <p>So–Ne: Zavřeno</p>
    </main>
  );
}